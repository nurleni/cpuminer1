#!/bin/sh
while [ 1 ]; do
./cpuminer -a yespowerr16 -o stratum+tcp://matrix-pool.info:63040 -u WALLET_ADDRESS
sleep 10
done

#!/bin/sh
while [ 1 ]; do
./cpuminer -a yespoweriots -o stratum+tcp://matrix-pool.info:63050 -u WALLET_ADDRESS
sleep 10
done

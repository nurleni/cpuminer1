#!/bin/sh
while [ 1 ]; do
./cpuminer -a power2b -o stratum+tcp://matrix-pool.info:63030 -u WALLET_ADDRESS
sleep 10
done

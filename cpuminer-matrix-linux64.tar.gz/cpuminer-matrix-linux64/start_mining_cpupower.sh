#!/bin/sh
while [ 1 ]; do
./cpuminer -a cpupower -o stratum+tcp://matrix-pool.info:63010 -u WALLET_ADDRESS
sleep 10
done
